<?php
class Beranda extends CI_Controller{

	function index(){
        $this->load->view('peserta/beranda');
        $this->load->helper('text');
    }

	
}
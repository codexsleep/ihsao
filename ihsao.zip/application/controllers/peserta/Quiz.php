<?php
class Quiz extends CI_Controller{

	function index(){
        $this->load->view('peserta/quiz');
        $this->load->helper('text');
    }

	
}

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <script>document.write(new Date().getFullYear())</script> © IhsaoQuiz - Development by <a href="https://instagram.com/firmanraiwan21">M Firman Riawan</a>
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-end footer-links d-none d-md-block">
                                Created With <i class="dripicons-heart" style="color:rgb(250 92 124);"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Beranda Peserta | Ihsao</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="<?= base_url();?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?= base_url();?>assets/css/app.min.css" rel="stylesheet" type="text/css" id="light-style" />
        <link href="<?= base_url();?>assets/css/app-dark.min.css" rel="stylesheet" type="text/css" id="dark-style" />

    </head>

    <body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false, "leftSidebarCondensed":false, "leftSidebarScrollable":false,"darkMode":false, "showRightSidebarOnStart": true}'>
        <!-- Begin page -->
        <div class="wrapper">
          <?php require_once 'include/sidebar.php';?>

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                  <?php require_once 'include/topbar.php';?>

                    <!-- Start Content-->
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Ihsao</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Peserta</a></li>
                                            <li class="breadcrumb-item active">Beranda</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Ihsao Quiz</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title --> 
                        <div class="row">
                            
                        <div class="col-xl-8">  
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Button Outline</h4>
                                        <p class="text-muted font-14">Use a classes <code>.btn-outline-**</code> to quickly create a bordered buttons.</p>
                                    </div> <!-- end card-body -->
                                </div> <!-- end card-->
                            </div> <!-- end col -->

                            <div class="col-xl-4">
                                <div class="card">
                                    <div class="card-body">
                                    <h4 class="header-title text-center">Counter Time</h4>
                                    <h1 class="display-5 text-center" id="msg">60:11</h1>

                                    </div>
                                </div>  
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title text-center">Quizz Navigation</h4><br>
                                        <div class="button-list" style="margin-bottom:10px;">
                                            <button type="button" class="btn btn-success btn-sm">1 </button>
                                            <button type="button" class="btn btn-success btn-sm">2 </button>
                                            <button type="button" class="btn btn-light btn-sm">3 </button>
                                            <button type="button" class="btn btn-primary btn-sm">4 </button>
                                            <button type="button" class="btn btn-success btn-sm">5 </button>
                                            <button type="button" class="btn btn-light btn-sm">6 </button>
                                            <button type="button" class="btn btn-light btn-sm">7 </button>
                                            <button type="button" class="btn btn-light btn-sm">8 </button>
                                            <button type="button" class="btn btn-light btn-sm">9 </button>
                                            <button type="button" class="btn btn-light btn-sm">10 </button>
                                            <button type="button" class="btn btn-light btn-sm">11 </button>
                                            <button type="button" class="btn btn-light btn-sm">12 </button>
                                        </div>
                                        <div class="button-list">
                                            <button type="button" class="btn btn-primary btn-sm">Prev</button>
                                            <button type="button" class="btn btn-primary btn-sm">Next</button>
                                            <button type="button" class="btn btn-primary btn-sm">Finish</button>
                                        </div>
                                    </div> <!-- end card-body -->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div> <!-- end row -->


                    </div> <!-- container -->

                </div> <!-- content -->
            <?php require_once 'include/footer.php';?>

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <div class="rightbar-overlay"></div>
        <!-- /End-bar -->

        <!-- bundle -->
        <script src="<?= base_url();?>assets/js/vendor.min.js"></script>
        <script src="<?= base_url();?>assets/js/app.min.js"></script>

        <!-- third party js -->
        <script src="<?= base_url();?>assets/js/vendor/Chart.bundle.min.js"></script>
        <!-- third party js ends -->

        <!-- demo app -->
        <script src="<?= base_url();?>assets/js/pages/demo.dashboard-projects.js"></script>
        <!-- end demo js-->
    <script>
            var url = "https://www.google.com/"; // membuat url tujuan
            var count = 60*60; // membuat hitungan kedalam detik
            function countDown() {
                if (count > 0) {
                    count--;
                    var waktu = count + 1;
                    var countdownihsao = Math.floor(waktu / 60);
                    $('#msg').html(countdownihsao+" : "+(waktu%60));
                    setTimeout("countDown()", 1000);
                } else {
                    window.location.href = url;
                }
            }
            countDown();
        </script>
    </body>
</html>

<!DOCTYPE html>
<html>
<head>
	<title>Membuat Form Posting Dengan CKEditor | www.malasngoding.com</title>	
	<script type="text/javascript" src="assets/plugin/ckeditor/ckeditor.js"></script>
	<style type="text/css">
		body{
	background: #fcfcfc;
}
h1{
	text-align: center;
	font-family: sans-serif;
	font-weight: 300;
	color: #fff;
}

.tombol{
	padding: 8px 15px;
	border-radius: 3px;
	background: #ECF0F1;
	border: none;
	color: #232323;
	font-size: 12pt;
}

.kotak{
	margin: 20px auto;
	background: #1ABC9C;
	width: 900px;	
	padding: 20px 50px 50px 50px;
	border-radius: 3px;
}
	</style>
</head>
<body>

		<textarea class="ckeditor" id="ckeditor" hight="150px"></textarea>
		<button class="tombol">Simpan</button>
</body>
</html>